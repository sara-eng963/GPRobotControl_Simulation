#!/usr/bin/env python3
"""P04 director-only, fail-closed incremental builder. No Git state changes.
Reads the existing uncommitted P04 checkout and emits/applies a 4-file patch.
"""
import argparse
import difflib
from pathlib import Path
import subprocess

BASE='916e7a85fd2d20f445fe513901f8d149260c09cb'
SUP='Firmware/STM32H745/CM7/Application/StateMachine/supervisor_task.c'
TEST='Firmware/Tests/test_p04_integrated.c'
MUT='Firmware/Tests/run_p04_mutations.py'
REPORT='Firmware/P04_INTEGRATED_TIMING_FAULT_INJECTION_REPORT.md'
PATHS=(SUP,TEST,MUT,REPORT)
PACKAGE=Path(__file__).resolve().parent

def replace_exact(s,a,b,label):
    n=s.count(a)
    if n!=1:
        raise ValueError(f'REFUSED {label}: expected one exact anchor, found {n}: {a[:100]!r}')
    return s.replace(a,b,1)

SUP_BEFORE='''        /* Complete, intentional Teaching break, or overload->FAULT: never
         * suspend state/fault stepping merely because messages arrived. */
        if (controller_hb_ok ||
            context->machine.activeState == ROBOT_STATE_FAULT ||
            context->machine.activeState == ROBOT_STATE_EMERGENCY_STOP)
        {
            run_active_state(context);
        }
'''
SUP_AFTER='''        /* Work after the initial wake check (queue, IPC, heartbeat and
         * authorization) can consume the remaining deadline. Recheck the
         * CM7-local TIM2 clock immediately before state dispatch. This
         * cannot predict duration of the subsequent state step. FAULT and
         * EMERGENCY_STOP service must still run after a timing fault. */
        if (hardware_timed &&
            !supervisor_timing_pre_dispatch_check(context, supervisor_now_us()))
            progress_cycle_ok = false;
        /* Complete, intentional Teaching break, or overload->FAULT: never
         * suspend state/fault stepping merely because messages arrived. */
        if (controller_hb_ok ||
            context->machine.activeState == ROBOT_STATE_FAULT ||
            context->machine.activeState == ROBOT_STATE_EMERGENCY_STOP)
        {
            run_active_state(context);
        }
'''

# Insert before P04 boundary fixture. This is an actual one-cycle invocation
# of supervisor_task_entry with deterministic scheduler/time callbacks, not
# a test that invokes the timing helper in isolation.
TEST_ANCHOR='static void p04_boundary_tests(void)\n{'
TEST_INSERT=r'''/* P04 director verification: run the actual production task entry, not
 * merely its separately callable timing policy helper. One synthetic release
 * is completed; the next wait exits through a test-only setjmp boundary.
 * All time is injected task-local CM7 time (not a hardware measurement). */
static jmp_buf p04_task_loop_exit;
static uint64_t p04_task_clock_us;
static unsigned p04_task_release_calls;
static SupervisorTimingWake p04_task_observation;
static bool p04_task_observation_present;
static unsigned p04_task_input_calls;

static uint64_t p04_task_clock(void *unused)
{
    (void)unused;
    return p04_task_clock_us;
}
static bool p04_task_timer_start(void *unused)
{
    (void)unused;
    return true;
}
static uint32_t p04_task_wait_release(void *unused, TickType_t ticks)
{
    (void)unused;
    P04_REQUIRE(ticks == pdMS_TO_TICKS(6U));
    if (++p04_task_release_calls == 2U)
        longjmp(p04_task_loop_exit, 1);
    P04_REQUIRE(p04_task_release_calls == 1U);
    return 1U;
}
static bool p04_task_observe(void *unused, uint32_t releases,
                             SupervisorTimingWake *out)
{
    (void)unused;
    P04_REQUIRE(releases == 1U && out != NULL);
    if (!p04_task_observation_present) return false;
    *out = p04_task_observation;
    return true;
}
/* Invalid timing must be rejected BEFORE any normal input acquisition.
 * If the initial preflight call is removed, this assertion fails even if
 * the later recheck would eventually detect the same invalid timestamp. */
static bool p04_task_input_requires_prior_fault(void *unused,
                                                  SupervisorInputSnapshot *out)
{
    ++p04_task_input_calls;
    P04_REQUIRE(ctx.machine.activeState == ROBOT_STATE_FAULT);
    P04_REQUIRE(ctx.machine.activeFaultCode ==
                state_error_code(ROBOT_STATE_APPROACH, 0xE019U));
    return p03_good_board_inputs(unused, out);
}
/* The initial wake is legal; model bounded input processing consuming time.
 * This is an injected delay, NOT a claim that GPIO acquisition takes 1901 us. */
static bool p04_task_input_expires_deadline(void *unused,
                                             SupervisorInputSnapshot *out)
{
    ++p04_task_input_calls;
    P04_REQUIRE(ctx.machine.activeState == ROBOT_STATE_APPROACH);
    p04_task_clock_us = UINT64_C(102001); /* 2001 us from serviced TIM3 ISR */
    return p03_good_board_inputs(unused, out);
}
/* The desktop fixture's hardware-timed task path does not call this API,
 * but the real task function includes the non-hardware fallback branch. */
void vTaskDelayUntil(TickType_t *previous, TickType_t ticks)
{
    (void)previous;
    (void)ticks;
    P04_REQUIRE(false); /* unexpected non-hardware scheduling path */
}
static void p04_task_entry_setup(bool initial_valid)
{
    p04_prep(ROBOT_STATE_APPROACH, 100U);
    ctx.config.ipc = (IpcShared *)&ctx; /* established mock mailbox */
    ctx.config.reset_diagnostics.captured = true;
    ctx.config.reset_diagnostics.cause = RESET_CAUSE_POWER_ON;
    ctx.config.drive_restart_board.read = p02_board_read;
    ctx.boot.preenable_status_checked = true;
    p02_authorization_press = true;
    master.controller_heartbeat_sent = true;
    master.last_controller_heartbeat_ms = 100U;
    /* Task entry itself binds the actual production CANopen owner; the
     * existing fixture normally installs its fake owner before this point. */
    master.owner_check = NULL;
    master.owner_check_context = NULL;
    for (unsigned axis = 0U; axis < JOINT_DRIVE_AXES; ++axis)
        drive.axis[axis].timestamp_us = UINT64_C(100000);
    p04_task_clock_us = UINT64_C(100100);
    p04_task_release_calls = 0U;
    p04_task_input_calls = 0U;
    p04_task_observation_present = initial_valid;
    p04_task_observation = p04_wake(UINT64_C(100000),
                                     UINT64_C(100100), 2000U);
    ctx.config.timing = (SupervisorTimingPort){
        .monotonic_us = p04_task_clock,
        .start = p04_task_timer_start,
        .wait_next = p04_task_wait_release,
        .observe_wake = p04_task_observe
    };
    g_timing = ctx.config.timing; /* same source used by supervisor_now_us */
    ctx.approach_control.home_requested = true; /* sentinel: untouched if no Approach step */
}
static void p04_task_entry_one_cycle(void)
{
    if (setjmp(p04_task_loop_exit) == 0)
        supervisor_task_entry(&ctx);
    P04_REQUIRE(p04_task_release_calls == 2U);
    P04_REQUIRE(p04_task_input_calls == 1U);
    P04_REQUIRE(ctx.machine.activeState == ROBOT_STATE_FAULT);
    P04_REQUIRE(ctx.restart_gate.inhibited);
    P04_REQUIRE(!master.drive_command_permission);
    P04_REQUIRE(ctx.fault_response_step_ok);
    P04_REQUIRE(ctx.approach_control.home_requested); /* no motion-state step */
    P04_REQUIRE(drive.commands == 0U);
    P04_REQUIRE(critical_depth == 0U);
}
static void p04_task_entry_timing_contracts(void)
{
    /* Case 1: prove the INITIAL production call site precedes input work. */
    p04_task_entry_setup(false);
    ctx.config.io.read_inputs = p04_task_input_requires_prior_fault;
    p04_task_entry_one_cycle();
    P04_REQUIRE(ctx.machine.activeFaultCode ==
                state_error_code(ROBOT_STATE_APPROACH, 0xE019U));

    /* Case 2: initial preflight passes; input work crosses 2 ms. The
     * dispatch-adjacent second check must fault BEFORE Approach stepping. */
    p04_task_entry_setup(true);
    ctx.config.io.read_inputs = p04_task_input_expires_deadline;
    p04_task_entry_one_cycle();
    P04_REQUIRE(ctx.machine.activeFaultCode ==
                state_error_code(ROBOT_STATE_APPROACH, 0xE004U));
    P04_REQUIRE(ctx.timer_overruns == 0U); /* distinct from execution overrun */
    P04_REQUIRE(ctx.timer_deadline_misses == 1U);
}

'''

MUT_INSERT=''' 'task_entry_early_callsite_bypass':(
     'if (hardware_timed &&\\n            !supervisor_timing_pre_dispatch_check(context, cycle_start_us))',
     'if (false && hardware_timed &&\\n            !supervisor_timing_pre_dispatch_check(context, cycle_start_us))'),
 'task_entry_predispatch_recheck_bypass':(
     'if (hardware_timed &&\\n            !supervisor_timing_pre_dispatch_check(context, supervisor_now_us()))',
     'if (false && hardware_timed &&\\n            !supervisor_timing_pre_dispatch_check(context, supervisor_now_us()))'),
'''

def transform(path,data):
    if path == SUP:
        if 'supervisor_timing_pre_dispatch_check' not in data:
            raise ValueError('REFUSED: previous P04 preflight missing')
        return replace_exact(data,SUP_BEFORE,SUP_AFTER,path)
    if path == TEST:
        data=replace_exact(data,TEST_ANCHOR,TEST_INSERT+TEST_ANCHOR,path)
        return replace_exact(data,'    p04_scenario_10();p04_boundary_tests();',
            '    p04_scenario_10();p04_task_entry_timing_contracts();p04_boundary_tests();',path)
    if path == MUT:
        return replace_exact(data,"SUPERVISOR={\n", "SUPERVISOR={\n"+MUT_INSERT,path)
    if path == REPORT:
        add='''\n## P04 director correction — production task-loop invocation and late pre-dispatch window\n\n**Independent WSL verification, supplied by the Engineering Director (not executed by this package author):** 56/56 CTests, 11/11 P04 scenario groups, 10/10 original compiled P04 mutations rejected, all four CM7/CM4 ARM Debug/Release builds and both firmware integration checks PASS. Retain the historical authoring-environment **NOT RUN** entries above; these are separate test runs and are not evidence of author execution. The following incremental correction requires its own WSL execution.\n\n**Production change:** The existing entry preflight check is retained. A second `supervisor_timing_pre_dispatch_check(context, supervisor_now_us())` now runs **after** input, queue, IPC, heartbeat, and drive authorization work, **immediately before** `run_active_state`. If the task-local TIM2 observation reaches 2000 us since serviced TIM3 ISR, E004 is entered and software permission is revoked before the motion-state call. Invalid observation still uses E019 and severe gap/missed releases E003. The FAULT/EMERGENCY_STOP servicing condition remains unchanged; no automatic recovery and no deadline relaxation. The second check does not predict future state-step runtime, CAN transmit completion or physical stop latency.\n\n**Real task-path executable tests:** `test_p04_integrated.c` now calls the actual static `supervisor_task_entry` for exactly one deterministic release, exiting at the next synthetic wait via `setjmp`. For missing initial timing evidence, an input-acquisition callback requires E019 already latched **before normal work**; bypassing the early production invocation fails the callback assertion even if the second check could eventually catch the same fault. For a valid initial wake, input acquisition advances injected CM7 time across the 2000 us limit, then tests require E004, inhibited drive permission, continued fault service, untouched Approach-request sentinel and zero target sends. No ISR/MCU execution time is measured.\n\n**New compiled source mutations:** `task_entry_early_callsite_bypass` and `task_entry_predispatch_recheck_bypass` are added to the existing ten. Expected total: **12**, subject to WSL execution (NOT RUN here). Both must compile, execute the actual task entry, and produce `P04_ASSERT_FAIL`, rather than pass on compiler errors. The existing 11 P04 output scenario groups and 56 CTests are intentionally unchanged.\n\n**Residual limitations:** Potential preemption or execution overrun *inside* `run_active_state` cannot be retroactively prevented by this guard; physical scheduling, CAN TX arbitration/feedback under saturation, genuine CM7/CM4 IPC contention, real timing WCET and hardware stop assurance remain **NOT VERIFIED / HARDWARE-PENDING**. No GPIO instrumentation or independent watchdog feeding was enabled.\n\n**Post-correction WSL verification: NOT RUN by executor in this environment.** Engineering Director must run the exact commands supplied in the incremental package README, capture compiled mutation results, CTest totals, ARM builds and `git diff --check` before accepting the incremental change.\n\n**Incremental artifact disposition: READY FOR DIRECTOR REVIEW.** This is a review readiness label, not an assertion that the two new mutations or production task-loop test passed WSL. No commit or push is authorized by this label.\n'''
        if '## P04 director correction' in data:
            raise ValueError('REFUSED: report already contains director correction section')
        data=replace_exact(data,'## 11. Final software disposition',
            '## 11. Historical executor disposition (original authoring environment)',path)
        return data.rstrip()+'\n'+add
    raise ValueError(path)

def check_git(repo):
    def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
    if git('rev-parse','HEAD')!=BASE:
        raise ValueError('REFUSED: HEAD mismatch, exact P03 base required')
    if git('symbolic-ref','--short','HEAD')!='sara/can-replacement':
        raise ValueError('REFUSED: authorized branch mismatch')
    return git

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    modes=p.add_mutually_exclusive_group(required=True)
    modes.add_argument('--check',action='store_true')
    modes.add_argument('--emit-patch',type=Path)
    modes.add_argument('--apply',action='store_true')
    args=p.parse_args()
    repo=args.repo.resolve()
    git=check_git(repo)
    existing={};changed={}
    for path in PATHS:
        src=repo/path
        if not src.is_file():raise ValueError(f'REFUSED missing prior P04 file {path}')
        existing[path]=src.read_text()
        changed[path]=transform(path,existing[path])
    # Prohibit mixed-in staged edits to the exact tracked production file.
    if git('diff','--cached','--name-only'):
        raise ValueError('REFUSED: staged changes present; do not mix staged commits with P04')
    if args.check:
        print('PASS: exact P03 HEAD, branch, all 4 P04 anchors, no staged files')
        return
    if args.emit_patch:
        sections=[]
        for path in PATHS:
            lines=list(difflib.unified_diff(existing[path].splitlines(keepends=True),
                                            changed[path].splitlines(keepends=True),
                                            fromfile='a/'+path,tofile='b/'+path,n=3))
            if not lines:raise ValueError('No delta generated: '+path)
            sections.append('diff --git a/'+path+' b/'+path+'\n'+''.join(lines))
        args.emit_patch.parent.mkdir(parents=True,exist_ok=True)
        args.emit_patch.write_text(''.join(sections))
        print('WROTE incremental diff',args.emit_patch)
        return
    # Write only the four known paths. No git add, reset, commit or checkout.
    for path in PATHS:
        (repo/path).write_text(changed[path]);print('UPDATED',path)
    print('PASS: uncommitted incremental source correction applied')

if __name__=='__main__':main()
