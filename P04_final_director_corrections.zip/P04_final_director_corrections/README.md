# P04 — Director timing containment corrections (incremental only)

**Source baseline:** P03 commit `916e7a85fd2d20f445fe513901f8d149260c09cb`, branch `sara/can-replacement`, **existing uncommitted P04 installation required**. This package does not replace P04 and does not make a Git commit, new branch, push, merge or reset.

## Exact changed repository files (4)

1. `Firmware/STM32H745/CM7/Application/StateMachine/supervisor_task.c` — one additional TIM2-based check after pre-dispatch work, immediately before `run_active_state()`. The original early check remains.
2. `Firmware/Tests/test_p04_integrated.c` — run the actual production `supervisor_task_entry()` for one deterministic control release using existing compiled production source and test mocks. The next wait exits via a test-only setjmp boundary. Missing initial timing observation must be faulted before any input callback; a valid initial wake becoming late during input acquisition must fault before Approach stepping. Assertions require E019/E004, permission revoked, continued FAULT servicing and no motor target dispatch.
3. `Firmware/Tests/run_p04_mutations.py` — two **new compiled source** mutations targeting distinct task-entry invocation sites; expected total 12 if independently executed, rather than original 10.
4. `Firmware/P04_INTEGRATED_TIMING_FAULT_INJECTION_REPORT.md` — append director verification provenance, new correction, verification limitations, and a separate **READY FOR DIRECTOR REVIEW** artifact disposition. Historical executor `NOT RUN` results are not edited.

No CMake changes or new CTests; previous 56 CTests and 11 P04 output groups are unchanged. The new test calls are included inside the existing `P04-BOUNDARY` group. The firmware modification introduces no new timing or safety APIs, dynamic allocation or logging.

## Incremental patch and safe application

The shipped `P04_director_incremental.patch` is a reviewable four-file unified diff constructed from the previous P04 package. **Prefer regenerating the exact diff using `build_incremental.py` against the installed P04 checkout** because the director's WSL modifications may differ. The builder finds exact unique source anchors and refuses duplicate/missing anchors and wrong branch/HEAD. In `--check` and `--emit-patch` modes it does not modify the checkout. `--apply` edits only the four named files, leaving other uncommitted work untouched. It refuses staged changes to avoid mixing changes. All runs require P03 HEAD but allow existing uncommitted P04 files; do **not** run the original `apply_p04.py` again.

Run in WSL, from the existing P04 checkout:

```bash
cd ~/freertos-pc-test
FIX=/path/to/extracted/P04_final_director_corrections

git branch --show-current
git rev-parse HEAD
git status --short

python3 "$FIX/build_incremental.py" --repo "$PWD" --check
python3 "$FIX/build_incremental.py" --repo "$PWD" \
  --emit-patch "$FIX/P04_exact_incremental_from_WSL.patch"
# Review the emitted patch BEFORE applying it.
python3 "$FIX/build_incremental.py" --repo "$PWD" --apply

git diff --check
python3 Firmware/Tests/run_p04_integrated.py
python3 Firmware/Tests/run_p04_mutations.py
# Full existing regression / ARM / integration runner, same commands as initial P04:
P04_EVIDENCE_DIR="$HOME/p04-director-final-evidence" bash "$FIX/verify_in_wsl.sh"
```

Expected *if all code and tests succeed*: `11/11` P04 groups, `12/12` compiled P04 mutations rejected, `56/56` CTests (no new CTest registration), four ARM builds, two integration checks and `git diff --check`. These are **expectations, not observed results from this authoring environment**.

## Current evidence and limits

- Confirmed previously by director: baseline P04 in independent WSL passed 56 CTests, 11 scenario groups, 10 source mutations, 4 ARM builds and 2 firmware integration checks.
- Current incremental correction: generated and syntax checked; unified patch passes `git apply --check` against a source-shaped temporary fixture; **not compiled against a complete repository checkout here**, so new mutations and integrated task-entry test are **NOT RUN**.
- Provenance of the injected delay: synthetic CM7 monotonic microseconds, not STM32 WCET, task-jitter measurement, or physical CAN transmission.
- Unchanged open risks: CAN saturation/backlog, independent CM7/CM4 IPC contention, CAN bus timing, hardware deadlines, physical stop/STO, and hardware watchdog assertions are pending.

**Final artifact disposition: READY FOR DIRECTOR REVIEW — uncommitted, with post-correction WSL verification pending.**
