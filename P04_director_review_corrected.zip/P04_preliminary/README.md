# P04 candidate — uncommitted exact-P03 baseline patch builder

**Disposition: INCOMPLETE / UNVERIFIED.** The attached artifacts are a real source-grounded candidate, not a compiled-and-approved P04 implementation. The execution environment could read the authoritative P03 source through GitHub, but had no complete repository checkout, FreeRTOS POSIX kernel checkout or ARM toolchain. No remote repository writes were performed.

## What is in the package

- `apply_p04.py` — strict branch/commit and SHA-1 Git blob guards for each existing file; never changes an existing locally modified file. `--check`, `--emit-patch`, `--apply` modes. Uses unique audited source anchors and refuses any output path collision.
- `P04_provisional.patch` — provisional unified diff for review. **Do not apply this file blindly**; the builder will regenerate the authoritative full diff from the exact local P03 source.
- `Firmware/Tests/test_p04_integrated.c` — production-TU integration fixture covering P04-01 through P04-10 and boundaries. Reuses, does not duplicate, the existing `test_production_supervisor.c` environment.
- `Firmware/Tests/run_p04_integrated.py`, `Firmware/Tests/run_p04_mutations.py` — candidate executable production-source runner and 10 source mutations, pending WSL validation.
- `Firmware/P04_INTEGRATED_TIMING_FAULT_INJECTION_REPORT.md` — audit, explicit nonverification, risk matrix and hardware requirements.
- `verify_in_wsl.sh` — sequential full test/ARM/integration command runner with stored logs. Invoke it from the P03 branch checkout; `P04_EVIDENCE_DIR` selects log destination.
- `local_source_check` — byte-verified copy (Git blob hash `ec879cda70c706259ebebc049c6472e4dae5a016`) of the exact P03 `supervisor_timing_quality.h` used for the locally executed C policy check. **Evidence only; do not add this duplicate to your firmware source tree.**

## WSL application — exact commands

```bash
cd /path/to/your/existing/GPRobotControl_Simulation
git status --short
git branch --show-current
git rev-parse HEAD
# Expected branch sara/can-replacement, commit 916e7a85fd2d20f445fe513901f8d149260c09cb

# Extract P04_preliminary.zip into a separate directory, never over the repo.
P04=/path/to/extracted/P04_preliminary
python3 "$P04/apply_p04.py" --repo "$PWD" --check
python3 "$P04/apply_p04.py" --repo "$PWD" --emit-patch "$P04/P04_exact_P03_uncommitted.patch"
python3 "$P04/apply_p04.py" --repo "$PWD" --apply

git status --short
git diff --check
bash "$P04/verify_in_wsl.sh"
```

The `--emit-patch` output is the exact-baseline unified diff including all new files. Generate it **before** `--apply`: the builder intentionally refuses reruns over its own modifications. No checkout modification occurs in `--check` or `--emit-patch` modes; the patch is written only at the explicit output path.

To review without touching your existing checkout: first use `--check` and `--emit-patch`; inspect the generated patch in a text editor. Do not proceed to `--apply` unless the candidate is acceptable. The builder refuses any changed tracked target or any existing new-file path rather than overwriting unrelated local work.

## Limitations

The P04 integration fixture and mutation suite have **not** been executed against the full production checkout. The candidate does **not** implement every required CAN backlog/backend fault-injection campaign or comprehensive CM4/IPC dual-core load tests. Run the existing actual FreeRTOS IPC transport test including P03 message types 6/7 as part of the WSL verification, not a mocked replacement. ARM builds, full CTest results and actual 500 Hz timing remain **NOT RUN / HARDWARE-PENDING**.

No live motor commands, hand-guiding activation, automatic authorization recovery or watchdog-feeding changes are present in this package. No commit, push, merge, reset or branch operation is performed by any script.

## Engineering Director source review correction

The P04-09 rollover fixture originally reversed `p03_progress(session, sequence, challenge)` arguments. This package corrects the invocation to `(71U, 1U, challenge)`. The P04 integrated tests, mutations, WSL build, and ARM builds remain **NOT RUN** in this authoring environment. The corrected package is not authorized for commit.
