#!/usr/bin/env python3
"""Exact-P03-baseline source-grounded P04 patch builder (no commits/branches).
Modes: --check, --emit-patch FILE, --apply. Rejects all modified target paths.
"""
import argparse
import difflib
import hashlib
from pathlib import Path
import subprocess
import sys

BASE = '916e7a85fd2d20f445fe513901f8d149260c09cb'
ORIGINAL = {
 'Firmware/STM32H745/CM7/Application/StateMachine/supervisor_task.c': '352269f272922f2922fc4c5f71235e701603313a',
 'Firmware/Tests/run_state_machine_alignment_tests.py': '8bcfa7ac6d978cafc43302b13f10d58053e6149b',
 'CMakeLists.txt': 'b5f4edc48ecb8a2bf0ed153c01218f0b6e83e842',
}
PAYLOAD = Path(__file__).resolve().parent
CREATED = [
 'Firmware/Tests/test_p04_integrated.c',
 'Firmware/Tests/run_p04_integrated.py',
 'Firmware/Tests/run_p04_mutations.py',
 'Firmware/P04_INTEGRATED_TIMING_FAULT_INJECTION_REPORT.md',
]

def replace_one(source, old, new, path):
    if source.count(old) != 1:
        raise ValueError(f'{path}: anchor count is {source.count(old)}, expected 1: {old[:65]}')
    return source.replace(old, new)

PREFLIGHT = '''/* P04: validate the source-owned TIM3 observation before entering a motion
 * state. Completion overruns remain post-execution (cannot be predicted);
 * no motion is executed after an already-observable late/invalid wake.
 * TIM3 service times and TIM2 wake sample share the CM7 clock domain. */
static bool supervisor_timing_pre_dispatch_check(
    SupervisorTaskContext *context, uint64_t task_now_us)
{
    const SupervisorTimingAssessment a = context->last_timing_wake_available
        ? supervisor_timing_assess(&context->last_timing_wake, task_now_us,
              context->previous_timing_wake_valid,
              context->previous_timing_wake_us)
        : (SupervisorTimingAssessment){0};
    uint32_t detail = 0U;
    if (!a.valid)
        detail = 0xE019U; /* invalid or missing CM7 timing evidence */
    else if (a.service_gap_severe || a.wake_gap_severe)
        detail = 0xE003U; /* serviced interrupt / wake cadence violated */
    else if (a.late_completion)
        detail = 0xE004U; /* task already >=2 ms from serviced IRQ */
    if (detail == 0U) return true;
    if (context->machine.activeState != ROBOT_STATE_FAULT &&
        context->machine.activeState != ROBOT_STATE_EMERGENCY_STOP)
        emit_step_failure(context, detail);
    return false;
}

'''

def transformed(path, data):
    if path.endswith('/supervisor_task.c'):
        data=replace_one(data,
          'static void supervisor_task_entry(void *argument)',
          PREFLIGHT+'static void supervisor_task_entry(void *argument)',path)
        data=replace_one(data,
          '        TRACE_BEGIN(TIMING_SUPERVISOR);\n        /* P03: actual production pre-dispatch cycle; tests call the same function. */',
          '        /* Reject known missed/invalid TIM3 timing before motor-state\n'
          '         * dispatch; completion overruns are evaluated after work. */\n'
          '        if (hardware_timed &&\n'
          '            !supervisor_timing_pre_dispatch_check(context, cycle_start_us))\n'
          '            progress_cycle_ok = false;\n'
          '        TRACE_BEGIN(TIMING_SUPERVISOR);\n'
          '        /* P03: actual production pre-dispatch cycle; tests call the same function. */',path)
    elif path.endswith('/run_state_machine_alignment_tests.py'):
        data=replace_one(data,
           '        execute(wrapper, "production Supervisor wrapper", wrapper=True)',
           '        if os.environ.get("P04_FAST_ONLY") == "1":\n'
           '            execute(TESTS / "test_p04_integrated.c",\n'
           '                    "P04 integrated production scenarios", wrapper=True)\n'
           '            return\n'
           '        execute(wrapper, "production Supervisor wrapper", wrapper=True)\n'
           '        execute(TESTS / "test_p04_integrated.c",\n'
           '                "P04 integrated production scenarios", wrapper=True)',path)
    elif path=='CMakeLists.txt':
        data=replace_one(data,
          '    set_tests_properties(stm32_state_machine_alignment PROPERTIES TIMEOUT 180)',
          '    set_tests_properties(stm32_state_machine_alignment PROPERTIES TIMEOUT 180)\n'
          '    add_test(NAME p04_integrated_production_scenarios\n'
          '        COMMAND "${Python3_EXECUTABLE}"\n'
          '            "${CMAKE_CURRENT_SOURCE_DIR}/Firmware/Tests/run_p04_integrated.py")\n'
          '    set_tests_properties(p04_integrated_production_scenarios PROPERTIES TIMEOUT 180)',path)
        # CMake may or may not have Python3 discovered: verify below.
        if 'find_package(Python3 ' not in data and 'find_package(Python3)' not in data:
            data=replace_one(data,'enable_testing()','enable_testing()\nfind_package(Python3 REQUIRED COMPONENTS Interpreter)',path)
    else:
        raise ValueError('Unexpected target '+path)
    return data

def git_blob(data):
    raw=data.encode('utf-8')
    return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def run(*args,cwd):
    return subprocess.check_output(args,cwd=cwd,text=True).strip()

def main():
    p=argparse.ArgumentParser()
    modes=p.add_mutually_exclusive_group(required=True)
    modes.add_argument('--check',action='store_true')
    modes.add_argument('--apply',action='store_true')
    modes.add_argument('--emit-patch',metavar='FILE',type=Path)
    p.add_argument('--repo',type=Path,default=Path.cwd())
    a=p.parse_args()
    repo=a.repo.resolve()
    if run('git','rev-parse','HEAD',cwd=repo)!=BASE:
        raise SystemExit(f'REFUSED: HEAD must equal P03 {BASE}')
    branch=run('git','symbolic-ref','--short','HEAD',cwd=repo)
    if branch!='sara/can-replacement':
        raise SystemExit('REFUSED: expected branch sara/can-replacement; actual '+branch)
    originals={}
    for path,digest in ORIGINAL.items():
        src=(repo/path).read_text()
        if git_blob(src)!=digest:
            raise SystemExit(f'REFUSED: {path} not exact P03 blob or locally modified')
        originals[path]=src
    for path in CREATED:
        if (repo/path).exists():
            raise SystemExit('REFUSED: output path already exists: '+path)
        if not (PAYLOAD/path).is_file():
            raise SystemExit('MISSING package payload '+path)
    modifications={k:transformed(k,v) for k,v in originals.items()}
    modifications.update({k:(PAYLOAD/k).read_text() for k in CREATED})
    if a.check:
        print('PASS exact branch HEAD, canonical source blobs, anchors and new-file collision checks')
        return
    if a.emit_patch:
        out=[]
        for path,data in modifications.items():
            existed=path in originals
            before=originals[path].splitlines(keepends=True) if existed else []
            after=data.splitlines(keepends=True)
            out.append(f'diff --git a/{path} b/{path}\n')
            if not existed:out.append('new file mode 100644\n')
            out += list(difflib.unified_diff(before,after,
                fromfile='a/'+path if existed else '/dev/null',
                tofile='b/'+path, n=3))
        a.emit_patch.parent.mkdir(parents=True,exist_ok=True)
        a.emit_patch.write_text(''.join(out))
        print('Generated exact-baseline candidate patch:',a.emit_patch)
        return
    # Only now does the builder touch the checkout. No Git write operations.
    for path,data in modifications.items():
        dest=repo/path
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(data)
        print('WROTE',path)
    print('Uncommitted P04 files installed; no commit/reset/push/merge executed.')

if __name__=='__main__':
    main()
