#!/usr/bin/env bash
# Run only after the exact-baseline builder installed the candidate changes.
# Execution is sequential and logs are preserved outside the repository.
set -Eeuo pipefail
ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"
OUT="${P04_EVIDENCE_DIR:-$HOME/p04-verification-evidence}"
mkdir -p "$OUT"
check() {
  local tag="$1";shift
  printf '\n== %s ==\n' "$tag"
  "$@" 2>&1 | tee "$OUT/$tag.log"
  printf 'PASS %s\n' "$tag" | tee -a "$OUT/summary.txt"
}
if [[ "$(git rev-parse --abbrev-ref HEAD)" != 'sara/can-replacement' ]] ||
   [[ "$(git rev-parse HEAD)" != '916e7a85fd2d20f445fe513901f8d149260c09cb' ]]; then
    echo 'FAIL: wrong branch/HEAD' >&2;exit 2
fi
printf 'P04 local verification — %s\n' "$(date -Iseconds)" > "$OUT/summary.txt"
check p04-integrated env P04_TRACE_FILE="$OUT/p04-scenarios.json" python3 Firmware/Tests/run_p04_integrated.py
check p04-mutations python3 Firmware/Tests/run_p04_mutations.py
check p03-runtime python3 Firmware/Tests/run_p03_runtime_evidence_tests.py
check p03-cm4 python3 Firmware/Tests/run_p03_cm4_service_tests.py
check p03-supervisor python3 Firmware/Tests/run_p03_supervisor_mutations.py
check p01-p02-supervisor python3 Firmware/Tests/run_state_machine_alignment_tests.py
check timing-extracted python3 Firmware/Tests/run_m7_timer_fault_injection.py
check ipc-posix bash Intercore/Tests/run_ipc_freertos_runtime.sh
check c2b-canopen python3 Firmware/Tests/run_c2b_canopen_master_tests.py
check c2b-restart python3 Firmware/Tests/run_drive_restart_gate_tests.py
check cmake-config cmake -S . -B build-p04 -DCMAKE_BUILD_TYPE=Debug
check cmake-build cmake --build build-p04 -j 4
check ctest-count ctest --test-dir build-p04 -N
check full-desktop-ctest ctest --test-dir build-p04 --output-on-failure -j 2
for config in Debug Release; do
  for core in CM7 CM4; do
    check "arm-${config}-${core}" python3 Firmware/Tests/build_stm32.py --core "$core" --config "$config"
  done
  check "integration-${config}" python3 Firmware/Tests/check_firmware_integration.py --build-root "$ROOT/build/stm32/${config}"
done
check git-diff-check git diff --check
printf 'Complete only if all commands PASS. This does not establish actual 500 Hz WCET.\n'
