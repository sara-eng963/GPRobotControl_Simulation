#!/usr/bin/env python3
"""Review-only unified diff based on audited P03 context fragments.
Use apply_p04.py --emit-patch on exact checkout for authoritative diff.
"""
from pathlib import Path
from difflib import unified_diff
import re
import apply_p04

ROOT=Path(__file__).parent

def chunk(path, start, old, new, new_offset=0):
    before=old.splitlines(keepends=True)
    after=new.splitlines(keepends=True)
    diff=list(unified_diff(before,after,fromfile='a/'+path,tofile='b/'+path,n=3))
    # Relocate from mini-fragment coordinates to the audited real source lines.
    header=diff[2]
    m=re.fullmatch(r'@@ -(\d+)(,\d+)? \+(\d+)(,\d+)? @@(.*)\n',header)
    if not m:raise ValueError(header)
    diff[2]=f'@@ -{int(m[1])+start-1}{m[2] or ""} +{int(m[3])+start-1+new_offset}{m[4] or ""} @@{m[5]}\n'
    return 'diff --git a/'+path+' b/'+path+'\n'+''.join(diff)

SUP='Firmware/STM32H745/CM7/Application/StateMachine/supervisor_task.c'
source='''    (void)supervisor_motion_containment_check(context, supervisor_now_ms(), false);
}

static void supervisor_task_entry(void *argument)
{
    SupervisorTaskContext *context = argument;
'''
new=source.replace('static void supervisor_task_entry(void *argument)',apply_p04.PREFLIGHT+'static void supervisor_task_entry(void *argument)')
parts=[chunk(SUP,1509,source,new)]
source='''        const uint64_t cycle_start_us =
            hardware_timed ? supervisor_now_us() : UINT64_C(0);
        TRACE_BEGIN(TIMING_SUPERVISOR);
        /* P03: actual production pre-dispatch cycle; tests call the same function. */
        supervisor_pre_dispatch_cycle(context);
'''
new=source.replace('        TRACE_BEGIN(TIMING_SUPERVISOR);\n',
 '''        /* Reject known missed/invalid TIM3 timing before motor-state
         * dispatch; completion overruns are evaluated after work. */
        if (hardware_timed &&
            !supervisor_timing_pre_dispatch_check(context, cycle_start_us))
            progress_cycle_ok = false;
        TRACE_BEGIN(TIMING_SUPERVISOR);
''')
parts.append(chunk(SUP,1570,source,new,new_offset=len(apply_p04.PREFLIGHT.splitlines())))
R='Firmware/Tests/run_state_machine_alignment_tests.py'
source='''        wrapper = TESTS / "test_production_supervisor.c"
        execute(wrapper, "production Supervisor wrapper", wrapper=True)

        # Reuse the same scheduling seam against the actual desktop wrapper
'''
new=source.replace('        execute(wrapper, "production Supervisor wrapper", wrapper=True)',
'''        if os.environ.get("P04_FAST_ONLY") == "1":
            execute(TESTS / "test_p04_integrated.c",
                    "P04 integrated production scenarios", wrapper=True)
            return
        execute(wrapper, "production Supervisor wrapper", wrapper=True)
        execute(TESTS / "test_p04_integrated.c",
                "P04 integrated production scenarios", wrapper=True)''')
parts.append(chunk(R,115,source,new))
C='CMakeLists.txt'
source='''        COMMAND "${Python3_EXECUTABLE}"
            "${CMAKE_CURRENT_SOURCE_DIR}/Firmware/Tests/run_state_machine_alignment_tests.py")
    set_tests_properties(stm32_state_machine_alignment PROPERTIES TIMEOUT 180)
    add_test(NAME stm32_portable_protocol_regressions
'''
new=source.replace('    set_tests_properties(stm32_state_machine_alignment PROPERTIES TIMEOUT 180)',
'''    set_tests_properties(stm32_state_machine_alignment PROPERTIES TIMEOUT 180)
    add_test(NAME p04_integrated_production_scenarios
        COMMAND "${Python3_EXECUTABLE}"
            "${CMAKE_CURRENT_SOURCE_DIR}/Firmware/Tests/run_p04_integrated.py")
    set_tests_properties(p04_integrated_production_scenarios PROPERTIES TIMEOUT 180)''')
parts.append(chunk(C,208,source,new))
for p in apply_p04.CREATED:
    data=(ROOT/p).read_text().splitlines(keepends=True)
    parts.append('diff --git a/'+p+' b/'+p+'\nnew file mode 100644\n'+''.join(
        unified_diff([],data,fromfile='/dev/null',tofile='b/'+p)))
(ROOT/'P04_provisional.patch').write_text(''.join(parts))
print('Wrote P04_provisional.patch (review-only; authoritative generated on exact P03 checkout)')
