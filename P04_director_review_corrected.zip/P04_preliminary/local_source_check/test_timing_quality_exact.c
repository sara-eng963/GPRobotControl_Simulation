#include "supervisor_timing_quality.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
static SupervisorTimingWake make(uint64_t isr,uint64_t wake,uint32_t gap){
    SupervisorTimingWake w={.isr_service_us=isr,.wake_sample_us=wake,
      .isr_service_gap_us=gap,.isr_gap_valid=gap!=0,
      .timestamp_valid=true};return w;
}
int main(void){
    SupervisorTimingWake w=make(100000,101999,2000);
    SupervisorTimingAssessment a=supervisor_timing_assess(&w,101999,false,0);
    assert(a.valid && !a.late_wakeup && !a.late_completion);
    w=make(100000,102000,2000);a=supervisor_timing_assess(&w,102000,false,0);
    assert(a.valid && a.late_wakeup && a.late_completion);
    w=make(100000,102001,2000);a=supervisor_timing_assess(&w,102001,false,0);
    assert(a.valid && a.late_wakeup && a.late_completion);
    w=make(100000,100001,4000);a=supervisor_timing_assess(&w,100002,false,0);
    assert(a.valid && a.service_gap_severe && a.service_gap_warning);
    w=make(100000,100002,2000);a=supervisor_timing_assess(&w,100003,true,96000);
    assert(a.valid && a.wake_gap_severe);
    w=make(100010,100001,2000);a=supervisor_timing_assess(&w,100011,false,0);
    assert(!a.valid);
    w=make(UINT32_MAX-2U,(uint64_t)UINT32_MAX+1U,2000);
    a=supervisor_timing_assess(&w,(uint64_t)UINT32_MAX+2U,false,0);
    assert(a.valid && a.isr_to_completion_us==4U);
    w=make(UINT64_MAX-100U,UINT64_MAX-1U,2000);
    a=supervisor_timing_assess(&w,UINT64_MAX,false,0);
    assert(a.valid && a.isr_to_completion_us==100U);
    puts("PASS: exact P03 production timing-quality header boundaries (host)");
    return 0;
}
