#!/usr/bin/env python3
"""Isolated C smoke: exact P03 timing-quality header + candidate helper.
Not a production Supervisor compile or integration test.
"""
from pathlib import Path
import hashlib
import subprocess
import sys
import tempfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from apply_p04 import PREFLIGHT

HERE=Path(__file__).resolve().parent
h=HERE/'supervisor_timing_quality.h'
raw=h.read_bytes()
digest=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
assert digest=='ec879cda70c706259ebebc049c6472e4dae5a016',digest
pre=r'''
#include "supervisor_timing_quality.h"
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#define ROBOT_STATE_FAULT 10
#define ROBOT_STATE_EMERGENCY_STOP 11
#define ROBOT_STATE_APPROACH 12
typedef struct { int activeState; } StateMachine;
typedef struct {
 StateMachine machine;
 bool last_timing_wake_available;
 SupervisorTimingWake last_timing_wake;
 bool previous_timing_wake_valid;
 uint64_t previous_timing_wake_us;
 uint32_t failed;
} SupervisorTaskContext;
static void emit_step_failure(SupervisorTaskContext *ctx,uint32_t detail)
{ ctx->failed=detail;ctx->machine.activeState=ROBOT_STATE_FAULT; }
'''
post=r'''
static SupervisorTimingWake wake(uint64_t isr,uint64_t w,uint32_t gap)
{ SupervisorTimingWake s={.isr_service_us=isr,.wake_sample_us=w,.timestamp_valid=true,
   .isr_gap_valid=true,.isr_service_gap_us=gap};return s; }
static SupervisorTaskContext start(uint64_t isr,uint64_t w,uint32_t gap)
{ SupervisorTaskContext s={.machine={ROBOT_STATE_APPROACH},
  .last_timing_wake_available=true,.last_timing_wake={0}};
  s.last_timing_wake=wake(isr,w,gap);return s; }
int main(void)
{
 SupervisorTaskContext c=start(100000,101999,2000);
 assert(supervisor_timing_pre_dispatch_check(&c,101999));
 assert(c.failed==0);
 c=start(100000,102000,2000);
 assert(!supervisor_timing_pre_dispatch_check(&c,102000));
 assert(c.failed==0xE004U && c.machine.activeState==ROBOT_STATE_FAULT);
 /* Wake was under 2 ms, but scheduling delayed actual pre-dispatch to 2 ms. */
 c=start(100000,101999,2000);
 assert(!supervisor_timing_pre_dispatch_check(&c,102000));
 assert(c.failed==0xE004U);
 c=start(100000,102001,2000);
 assert(!supervisor_timing_pre_dispatch_check(&c,102001));
 assert(c.failed==0xE004U);
 c=start(100000,100001,4000);
 assert(!supervisor_timing_pre_dispatch_check(&c,100002));
 assert(c.failed==0xE003U);
 c=start(100002,100001,2000);
 assert(!supervisor_timing_pre_dispatch_check(&c,100003));
 assert(c.failed==0xE019U);
 c=start(100000,100001,2000);
 c.last_timing_wake_available=false;
 assert(!supervisor_timing_pre_dispatch_check(&c,100010));
 assert(c.failed==0xE019U);
 puts("PASS candidate pre-dispatch helper isolated C smoke (NOT production integration)");
}
'''
with tempfile.TemporaryDirectory(prefix='p04-preflight-') as tmp:
    source=Path(tmp)/'smoke.c'
    source.write_text(pre+PREFLIGHT+post)
    exe=Path(tmp)/'smoke'
    build=subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror',
       '-I'+str(HERE),str(source),'-o',str(exe)],capture_output=True,text=True)
    if build.returncode:raise RuntimeError(build.stderr)
    subprocess.run([str(exe)],check=True)
