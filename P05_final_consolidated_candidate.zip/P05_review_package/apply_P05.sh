#!/usr/bin/env bash
# Consolidated P05 patch; no Git history writes or destructive cleanup.
set -euo pipefail
CHECKOUT="${1:-$HOME/freertos-pc-test}"
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BASE=ba5ab122868bd50a4626c568574be106dfce98fe
BRANCH=sara/can-replacement
[[ -d "$CHECKOUT/.git" ]] || { echo 'No existing Git checkout' >&2; exit 2; }
head="$(git -C "$CHECKOUT" rev-parse HEAD)"
branch="$(git -C "$CHECKOUT" branch --show-current)"
[[ "$head" == "$BASE" && "$branch" == "$BRANCH" ]] || {
    echo "Refusing: expected $BRANCH@$BASE; observed $branch@$head" >&2; exit 3;
}
# Ignore historical untracked ZIPs and patches; NEVER ignore tracked changes.
git -C "$CHECKOUT" diff --quiet -- || {
    echo 'Refusing: tracked worktree changes exist' >&2; exit 4;
}
git -C "$CHECKOUT" diff --cached --quiet -- || {
    echo 'Refusing: staged changes exist' >&2; exit 4;
}
# git apply --check independently rejects any new-file collision, including
# untracked source files, and detects tracked source mismatches.
git -C "$CHECKOUT" apply --check --whitespace=error "$HERE/P05.patch"
git -C "$CHECKOUT" apply --whitespace=error "$HERE/P05.patch"
git -C "$CHECKOUT" diff --check
printf 'Consolidated P05 applied, uncommitted. Review and run WSL tests.\n'
