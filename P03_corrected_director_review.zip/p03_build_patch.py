#!/usr/bin/env python3
"""Generate P03 diff from EXACT 620da1b source. Does not modify checkout.
This builder prevents silently applying transformations to unexpected upstream changes.
"""
from pathlib import Path
import difflib, subprocess, sys
ROOT = Path(sys.argv[1]) if len(sys.argv)>1 else Path.cwd()
OUT = Path(sys.argv[2]) if len(sys.argv)>2 else Path('P03_runtime_safety_liveness.patch')
BASE='620da1bbdf7b33304c2040bfb518292ff256dc43'
# Verify the actual canonical checkout. Do not rewrite a moved branch or
# overwrite overlapping uncommitted work. Unrelated dirty paths are untouched.
def git(*args):
    return subprocess.run(['git','-C',str(ROOT),*args],check=True,
        capture_output=True,text=True).stdout.strip()
if git('rev-parse','HEAD') != BASE:
    raise RuntimeError('Baseline HEAD moved: inspect/reconcile before generating P03')
if git('branch','--show-current') != 'sara/can-replacement':
    raise RuntimeError('Expected canonical sara/can-replacement checkout')
TARGETS = [
 'Intercore/ipc_mailbox.h',
 'Firmware/STM32H745/Common/Inc/ipc_mailbox.h',
 'Firmware/STM32H745/Common/Inc/runtime_evidence.h',
 'Firmware/STM32H745/CM7/Application/StateMachine/supervisor_task.h',
 'Firmware/STM32H745/CM7/Application/StateMachine/supervisor_task.c',
 'Firmware/STM32H745/CM4/Core/Src/application_ipc_service.c',
 'Firmware/Tests/test_production_supervisor.c',
 'Firmware/Tests/test_p03_runtime_evidence.c',
 'Firmware/Tests/run_p03_runtime_evidence_tests.py',
 'Firmware/Tests/test_p03_cm4_service.c',
 'Firmware/Tests/run_p03_cm4_service_tests.py',
 'Firmware/Tests/run_p03_supervisor_mutations.py',
 'Firmware/Tests/p03_cm4_mocks/FreeRTOS.h',
 'Firmware/Tests/p03_cm4_mocks/task.h',
 'Firmware/Tests/p03_cm4_mocks/queue.h',
 'Firmware/Tests/p03_cm4_mocks/message_buffer.h',
 'Firmware/P03_RUNTIME_SAFETY_LIVENESS_REPORT.md']
if git('status','--porcelain','--',*TARGETS):
    raise RuntimeError('Overlapping dirty/untracked P03 paths; never overwrite')
files={}

def load(p):
    if p not in files:
        src=ROOT/p
        if not src.is_file(): raise RuntimeError(f'MISSING {p}')
        files[p]=[src.read_text(),src.read_text()]
    return files[p][1]

def replace(p, old, new, count=1):
    s=load(p)
    n=s.count(old)
    if n!=count: raise RuntimeError(f'EXPECTED {count} anchor(s) in {p}, got {n}: {old[:110]!r}')
    files[p][1]=s.replace(old,new)

def append(p,s):
    old=load(p); files[p][1]=old+s

def add(p,source):
    if (ROOT/p).exists(): raise RuntimeError(f'P03 output exists: {p}')
    files[p]=['',source]

for p in ['Intercore/ipc_mailbox.h','Firmware/STM32H745/Common/Inc/ipc_mailbox.h']:
    replace(p, '    IPC_DIAGNOSTICS = 5\n',
            '    IPC_DIAGNOSTICS = 5,\n    /* P03 protocol v2. Fixed 60-byte application ABI is retained. */\n    IPC_CM4_PROGRESS = 6,\n    IPC_CM4_HELLO = 7\n')

p='Firmware/STM32H745/CM7/Application/StateMachine/supervisor_task.h'
replace(p, '#include "../../../Common/Inc/drive_restart_gate.h"',
    '#include "../../../Common/Inc/drive_restart_gate.h"\n#include "../../../Common/Inc/runtime_evidence.h"')
replace(p, '    ResetDiagnostics reset_diagnostics;\n',
    '    ResetDiagnostics reset_diagnostics;\n'
    '    /* Provisional P03 commissioning contracts; null => default denial. */\n'
    '    RuntimeSafetyPort safety_evidence;\n'
    '    RuntimeIpcSessionPort ipc_session;\n')

p='Firmware/STM32H745/CM7/Application/StateMachine/supervisor_task.c'
replace(p,'    DriveRestartGate restart_gate;\n',
    '    DriveRestartGate restart_gate;\n'
    '    RuntimeSafetyEvidence safety_evidence;\n'
    '    RuntimePeerEvidence peer_evidence;\n')
replace(p, '/* Only M7 consumes the M4->M7 ring. No shared FreeRTOS queue or mutex. */',
    '/* P03: both explicit CM4 protocol rejection and timeout fault here. */\n'
    'static void emit_step_failure(SupervisorTaskContext *context, uint32_t detail);\n'
    '/* Only M7 consumes the M4->M7 ring. No shared FreeRTOS queue or mutex. */')
replace(p,'        if (msg.type != IPC_HMI_COMMAND || msg.sequence == 0U ||\n',
    '        if (msg.type == IPC_CM4_HELLO) {\n'
    '            if (!runtime_peer_on_hello(&context->peer_evidence, &msg) &&\n'
    '                context->restart_gate.authorized &&\n'
    '                context->machine.activeState != ROBOT_STATE_FAULT &&\n'
    '                context->machine.activeState != ROBOT_STATE_EMERGENCY_STOP)\n'
    '                emit_step_failure(context, 0xE018U);\n'
    '            continue;\n'
    '        }\n'
    '        if (msg.type == IPC_CM4_PROGRESS) {\n'
    '            if (!runtime_peer_accept(&context->peer_evidence, &msg,\n'
    '                                     supervisor_now_ms()) &&\n'
    '                context->restart_gate.authorized &&\n'
    '                context->machine.activeState != ROBOT_STATE_FAULT &&\n'
    '                context->machine.activeState != ROBOT_STATE_EMERGENCY_STOP)\n'
    '                emit_step_failure(context, 0xE018U);\n'
    '            continue;\n'
    '        }\n'
    '        /* Old CM7 sessions and prior challenge generations cannot replay HMI. */\n'
    '        if (msg.type != IPC_HMI_COMMAND ||\n'
    '            !runtime_peer_fresh(&context->peer_evidence, supervisor_now_ms()) ||\n'
    '            msg.data[1] != context->peer_evidence.expected_session ||\n'
    '            msg.data[2] == 0U ||\n'
    '            msg.data[2] != context->peer_evidence.last_accepted_challenge)\n'
    '            continue;\n'
    '        if (msg.type != IPC_HMI_COMMAND || msg.sequence == 0U ||\n')
replace(p, '    msg.data[6] = context->machine.rejectedEventCount;\n',
    '    msg.data[6] = context->machine.rejectedEventCount;\n'
    '    msg.data[7] = context->peer_evidence.expected_session;\n'
    '    msg.data[8] = RUNTIME_PEER_PROTOCOL_VERSION;\n'
    '    /* One outstanding CM7-local round-trip; retransmit same nonce. */\n'
    '    uint32_t challenge = 0U;\n'
    '    if (runtime_peer_challenge(&context->peer_evidence, now, &challenge))\n'
    '        msg.data[9] = challenge;\n'
    '    msg.data[10] = context->peer_evidence.last_accepted_challenge;\n')
replace(p, '        .safety_valid = s->statusValid && s->motionPermitted,\n',
    '        .safety_valid = s->statusValid && s->motionPermitted &&\n'
    '            runtime_safety_fresh(&context->safety_evidence,\n'
    '                                 &context->config.safety_evidence, now_ms),\n')
replace(p,'        .ipc_valid = context->config.ipc != NULL &&\n                     ipc_valid(context->config.ipc),\n',
    '        .ipc_valid = context->config.ipc != NULL &&\n'
    '                     ipc_valid(context->config.ipc) &&\n'
    '                     runtime_peer_fresh(&context->peer_evidence, now_ms),\n')
replace(p, '        case SUPERVISOR_MESSAGE_SAFETY:\n        {\n            state_machine_update_safety(&context->machine,\n                                        &message->data.safety);\n',
    '        case SUPERVISOR_MESSAGE_SAFETY:\n        {\n'
    '            const RobotSafetySnapshot *incoming = &message->data.safety;\n'
    '            /* An unverified unsafe observation may still ASSERT a stop;\n'
    '             * it can never clear one. Preserve E-stop precedence. */\n'
    '            if (incoming->estopActive &&\n'
    '                context->machine.activeState != ROBOT_STATE_EMERGENCY_STOP) {\n'
    '                const SupervisorEvent stop = make_result_event(\n'
    '                    SUPERVISOR_EVENT_ESTOP_ASSERTED,\n'
    '                    context->machine.activeState,\n'
    '                    ROBOT_FAULT_SEVERITY_EMERGENCY,\n'
    '                    ROBOT_FAULT_CODE_EMERGENCY_STOP);\n'
    '                handle_policy_event(context, &stop);\n'
    '                return;\n'
    '            }\n'
    '            if (incoming->protectiveStopActive &&\n'
    '                context->machine.activeState != ROBOT_STATE_FAULT &&\n'
    '                context->machine.activeState != ROBOT_STATE_EMERGENCY_STOP) {\n'
    '                const SupervisorEvent stop = make_result_event(\n'
    '                    SUPERVISOR_EVENT_PROTECTIVE_STOP_ASSERTED,\n'
    '                    context->machine.activeState,\n'
    '                    ROBOT_FAULT_SEVERITY_PROTECTIVE_STOP,\n'
    '                    ROBOT_FAULT_CODE_PROTECTIVE_STOP);\n'
    '                handle_policy_event(context, &stop);\n'
    '                return;\n'
    '            }\n'
    '            if (!runtime_safety_accept(&context->safety_evidence,\n'
    '                                       &context->config.safety_evidence,\n'
    '                                       incoming, supervisor_now_ms())) {\n'
    '                /* Do not replace the last trusted sample with replay. */\n'
    '                if (context->restart_gate.authorized &&\n'
    '                    context->machine.activeState != ROBOT_STATE_FAULT &&\n'
    '                    context->machine.activeState != ROBOT_STATE_EMERGENCY_STOP)\n'
    '                    emit_step_failure(context, 0xE017U);\n'
    '                return;\n'
    '            }\n'
    '            state_machine_update_safety(&context->machine, incoming);\n')
replace(p,'static void supervisor_task_entry(void *argument)\n',
    '/* P03: called on EVERY 500 Hz cycle before any active-state dispatch.\n'
    ' * Fault service is never conditional on additional peer traffic. */\n'
    'static void supervisor_runtime_evidence_check(\n'
    '    SupervisorTaskContext *context, uint32_t now_ms)\n'
    '{\n'
    '    if (!context->restart_gate.authorized ||\n'
    '        context->machine.activeState == ROBOT_STATE_FAULT ||\n'
    '        context->machine.activeState == ROBOT_STATE_EMERGENCY_STOP)\n'
    '        return;\n'
    '    if (!runtime_safety_fresh(&context->safety_evidence,\n'
    '                              &context->config.safety_evidence, now_ms))\n'
    '        emit_step_failure(context, 0xE017U);\n'
    '    else if (!runtime_peer_fresh(&context->peer_evidence, now_ms))\n'
    '        emit_step_failure(context, 0xE018U);\n'
    '}\n\n'
    'static void supervisor_pre_dispatch_cycle(SupervisorTaskContext *context)\n'
    '{\n'
    '    supervisor_sample_inputs(context);\n'
    '    supervisor_process_message_batch(context);\n'
    '    consume_m4_ipc(context);\n'
    '    supervisor_runtime_evidence_check(context, supervisor_now_ms());\n'
    '    (void)supervisor_motion_containment_check(context, supervisor_now_ms(), false);\n'
    '}\n\n'
    'static void supervisor_task_entry(void *argument)\n')
replace(p, '        /* Read and validate inputs before consuming queued motion messages. */\n'
           '        supervisor_sample_inputs(context);\n'
           '        supervisor_process_message_batch(context);\n\n'
           '        consume_m4_ipc(context);\n'
           '        /* One bounded preflight per cycle: no state module may issue a new\n'
           '         * coordinated motion command after a monitored network/axis loss. */\n'
           '        (void)supervisor_motion_containment_check(\n'
           '            context, supervisor_now_ms(), false);\n',
    '        /* P03: actual production pre-dispatch cycle; tests call the same function. */\n'
    '        supervisor_pre_dispatch_cycle(context);\n')
replace(p,'    g_supervisor.config = *config;\n    g_timing = config->timing;\n',
    '    g_supervisor.config = *config;\n'
    '    /* A unique CM7 boot session must be issued by a real provider.\n'
    '     * Zero remains default-denied; no synthetic tick-derived token. */\n'
    '    uint32_t boot_session = 0U;\n'
    '    if (config->ipc_session.issue != NULL &&\n'
    '        !runtime_session_issue(&config->ipc_session, &boot_session))\n'
    '        return false;\n'
    '    g_supervisor.peer_evidence.expected_session = boot_session;\n'
    '    g_timing = config->timing;\n')

p='Firmware/STM32H745/CM4/Core/Src/application_ipc_service.c'
replace(p, '#include "task.h"\n', '#include "task.h"\n#include "../../../Common/Inc/runtime_evidence.h"\n')
replace(p, 'static uint32_t next_command_sequence;\n',
    'static uint32_t next_command_sequence;\n'
    'static uint32_t current_m7_session;\n'
    'static bool hello_sent;\n'
    'static uint32_t pending_challenge;\n'
    'static uint32_t last_seen_challenge;\n'
    'static uint32_t last_sent_challenge;\n'
    'static uint32_t confirmed_challenge;\n')
replace(p,'        if (!hmi_status_decode(&message, last_status_sequence,\n                                  &snapshot.status))\n            continue;\n',
    '        if (message.type != IPC_CONTROLLER_STATUS ||\n'
    '            message.data[7] == 0U ||\n'
    '            message.data[8] != RUNTIME_PEER_PROTOCOL_VERSION)\n'
    '            continue;\n'
    '        if (current_m7_session != 0U &&\n'
    '            message.data[7] != current_m7_session) {\n'
    '            /* A changed controller session invalidates all pending HMI.\n'
    '             * Last-sequence reset is safe only because CM7 rejects a\n'
    '             * command whose session token differs from its own. */\n'
    '            invalidate_pending = true;\n'
    '            last_status_sequence = 0U;\n'
    '            (void)xQueueReset(command_queue);\n'
    '        }\n'
    '        if (!hmi_status_decode(&message, last_status_sequence,\n'
    '                                  &snapshot.status))\n'
    '            continue;\n'
    '        if (message.data[7] != current_m7_session) {\n'
    '            hello_sent = false;\n'
    '            pending_challenge = 0U;\n'
    '            last_seen_challenge = 0U;\n'
    '            last_sent_challenge = 0U;\n'
    '            confirmed_challenge = 0U;\n'
    '        }\n'
    '        current_m7_session = message.data[7];\n'
    '        if (hello_sent && message.data[9] != 0U &&\n'
    '            (last_seen_challenge == 0U ||\n'
    '             runtime_forward(message.data[9], last_seen_challenge))) {\n'
    '            last_seen_challenge = message.data[9];\n'
    '            pending_challenge = last_seen_challenge;\n'
    '        }\n'
    '        if (hello_sent && message.data[10] != 0U &&\n'
    '            message.data[10] == last_sent_challenge)\n'
    '            confirmed_challenge = message.data[10];\n')
replace(p,'        } else {\n            if (pending == SUP_HMI_COMMAND_COUNT)\n',
    '        } else if (current_m7_session != 0U && hello_sent &&\n'
    '                   confirmed_challenge != 0U) {\n'
    '            if (pending == SUP_HMI_COMMAND_COUNT)\n')
replace(p,'                command.data[0] = (uint32_t)pending;\n',
    '                command.data[0] = (uint32_t)pending;\n'
    '                command.data[1] = current_m7_session;\n'
    '                command.data[2] = confirmed_challenge;\n')
replace(p,'        taskEXIT_CRITICAL();\n        vTaskDelayUntil(&last_wake, APPLICATION_IPC_PERIOD_TICKS);\n',
    '        taskEXIT_CRITICAL();\n'
    '        /* Every CM4 APPLICATION BOOT sends HELLO before progress/HMI.\n'
    '         * A full mailbox retries, and cannot silently skip HELLO. */\n'
    '        if (!hello_sent && current_m7_session != 0U) {\n'
    '            IpcMessage hello = {0};\n'
    '            hello.type = IPC_CM4_HELLO;\n'
    '            hello.sequence = 1U;\n'
    '            hello.data[0] = current_m7_session;\n'
    '            hello.data[1] = RUNTIME_PEER_PROTOCOL_VERSION;\n'
    '            hello.data[2] = 1U;\n'
    '            hello_sent = ipc_m4_send(shared_ipc, &hello);\n'
    '        }\n'
    '        /* Reply once to a challenge SEEN BEFORE this completed service\n'
    '         * cycle. CM7 checks its own issue-to-receipt round-trip age.\n'
    '         * No free-running CM4 progress floods the bounded mailbox. */\n'
    '        if (hello_sent && pending_challenge != 0U &&\n'
    '            pending_challenge != last_sent_challenge) {\n'
    '            SupervisionProgressSample sample = {0};\n'
    '            if (application_ipc_service_get_progress(&sample) &&\n'
    '                sample.completed_ok && sample.response_ok &&\n'
    '                sample.mode == SUP_PROGRESS_SERVICE) {\n'
    '                IpcMessage message = {0};\n'
    '                message.type = IPC_CM4_PROGRESS;\n'
    '                message.sequence = sample.sequence;\n'
    '                message.timestamp_ms = sample.completed_tick_ms; /* CM4-local */\n'
    '                message.data[0] = current_m7_session;\n'
    '                message.data[1] = RUNTIME_PEER_PROTOCOL_VERSION;\n'
    '                message.data[2] = (uint32_t)sample.mode;\n'
    '                message.data[3] = (uint32_t)sample.completed_ok;\n'
    '                message.data[4] = (uint32_t)sample.valid;\n'
    '                message.data[5] = (uint32_t)sample.response_ok;\n'
    '                message.data[6] = pending_challenge;\n'
    '                if (ipc_m4_send(shared_ipc, &message)) {\n'
    '                    last_sent_challenge = pending_challenge;\n'
    '                    pending_challenge = 0U;\n'
    '                }\n'
    '            }\n'
    '        }\n'
    '        vTaskDelayUntil(&last_wake, APPLICATION_IPC_PERIOD_TICKS);\n')

p='Firmware/Tests/test_production_supervisor.c'
replace(p, 'bool ipc_m7_send(IpcShared *ipc, const IpcMessage *msg)\n{ (void)ipc; (void)msg; return false; }\n',
    'static IpcMessage p03_last_m7_status;\n'
    'bool ipc_m7_send(IpcShared *ipc, const IpcMessage *msg)\n'
    '{ (void)ipc; p03_last_m7_status = *msg; return true; }\n')
replace(p, 'bool ipc_m7_receive(IpcShared *ipc, IpcMessage *msg)\n{ (void)ipc; (void)msg; return false; }\n',
    'static IpcMessage p03_ipc_frames[16];\n'
    'static unsigned p03_ipc_read, p03_ipc_write;\n'
    '#ifndef ALIGNMENT_DESKTOP\n'
    'static void p03_ipc_push(IpcMessage msg)\n'
    '{\n'
    '    if (p03_ipc_write < 16U) p03_ipc_frames[p03_ipc_write++] = msg;\n'
    '}\n'
    '#endif\n'
    'bool ipc_m7_receive(IpcShared *ipc, IpcMessage *msg)\n'
    '{\n'
    '    (void)ipc;\n'
    '    if (p03_ipc_read >= p03_ipc_write) return false;\n'
    '    *msg = p03_ipc_frames[p03_ipc_read++];\n'
    '    return true;\n'
    '}\n')
replace(p, '    state_machine_init(&ctx.machine);\n',
    '#ifndef ALIGNMENT_DESKTOP\n'
    '    p03_ipc_read = p03_ipc_write = 0U;\n'
    '#endif\n'
    '    state_machine_init(&ctx.machine);\n')
replace(p, 'static void setup(RobotStateId state)\n',
    '#ifndef ALIGNMENT_DESKTOP\n'
    'static uint32_t p03_fixture_sequence;\n'
    'static bool p03_fixture_verify(void *unused,\n'
    '    const RobotSafetySnapshot *s, uint32_t *session, uint32_t *sequence)\n'
    '{\n'
    '    (void)unused; (void)s;\n'
    '    *session = 51U; *sequence = ++p03_fixture_sequence;\n'
    '    return true;\n'
    '}\n'
    '#endif\n'
    'static void setup(RobotStateId state)\n')
replace(p, '    state_teaching_enter(&ctx.teaching, &teaching_config, 42U);\n',
    '#ifndef ALIGNMENT_DESKTOP\n'
    '    ctx.config.safety_evidence = (RuntimeSafetyPort){\n'
    '        .verify=p03_fixture_verify, .max_age_ms=100U };\n'
    '    p03_fixture_sequence = 0U;\n'
    '#endif\n'
    '    state_teaching_enter(&ctx.teaching, &teaching_config, 42U);\n')
replace(p, '    p02_motion_ready_master(400U);\n    master.drive_command_permission = false;\n',
    '    p02_motion_ready_master(400U);\n'
    '    /* Explicit test evidence, never the physical default. */\n'
    '    now_tick = 400U;\n'
    '    ctx.machine.safety.timestampMs = 400U;\n'
    '    ctx.safety_evidence = (RuntimeSafetyEvidence){\n'
    '        .accepted=true, .producer_session=51U, .last_sequence=1U,\n'
    '        .last_source_ms=400U, .last_receipt_ms=400U };\n'
    '    p03_fixture_sequence = 1U;\n'
    '    ctx.peer_evidence = (RuntimePeerEvidence){\n'
    '        .accepted=true, .expected_session=71U, .hello_seen=true,\n'
    '        .last_sequence=1U, .have_sequence=true, .last_response_ms=400U,\n'
    '        .last_accepted_challenge=1U };\n'
    '    master.drive_command_permission = false;\n')
replace(p, '    boot_safety.data.safety = ctx.machine.safety;\n    handle_message(&ctx, &boot_safety);\n',
    '    boot_safety.data.safety = ctx.machine.safety;\n'
    '    boot_safety.data.safety.timestampMs = 401U;\n'
    '    now_tick = 401U;\n'
    '    handle_message(&ctx, &boot_safety);\n')
replace(p, '#endif\n\nint main(void)\n',
    (Path(__file__).with_name('p03_fixture_extra.cfrag')).read_text() +
    '#endif\n\nint main(void)\n')
replace(p, '    test_p02_queue_and_board_failure();\n#endif\n',
    '    test_p02_queue_and_board_failure();\n'
    '    test_p03_fault_evidence();\n'
    '#endif\n')

add('Firmware/STM32H745/Common/Inc/runtime_evidence.h',
    (Path(__file__).with_name('runtime_evidence.h')).read_text())
add('Firmware/Tests/test_p03_runtime_evidence.c',
    (Path(__file__).with_name('test_p03_runtime_evidence.c')).read_text())
add('Firmware/Tests/run_p03_runtime_evidence_tests.py',
    (Path(__file__).with_name('run_p03_runtime_evidence_tests.py')).read_text())
for test_stub in ('FreeRTOS.h', 'task.h', 'queue.h', 'message_buffer.h'):
    add('Firmware/Tests/p03_cm4_mocks/' + test_stub,
        (Path(__file__).with_name('p03_cm4_mocks') / test_stub).read_text())
add('Firmware/Tests/run_p03_supervisor_mutations.py',
    (Path(__file__).with_name('run_p03_supervisor_mutations.py')).read_text())
add('Firmware/Tests/test_p03_cm4_service.c',
    (Path(__file__).with_name('test_p03_cm4_service.c')).read_text())
add('Firmware/Tests/run_p03_cm4_service_tests.py',
    (Path(__file__).with_name('run_p03_cm4_service_tests.py')).read_text())
add('Firmware/P03_RUNTIME_SAFETY_LIVENESS_REPORT.md',
    (Path(__file__).with_name('P03_RUNTIME_SAFETY_LIVENESS_REPORT.md')).read_text())

parts=[]
for path,(old,new) in files.items():
    if old==new: continue
    diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),
               fromfile='a/'+path if old else '/dev/null',
               tofile='b/'+path,n=3))
    parts.append(diff)
OUT.write_text(''.join(parts))
print(f'GENERATED {OUT} ({len(parts)} files, {sum(map(len,parts))} bytes)')
