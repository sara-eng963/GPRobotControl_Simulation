# P03 revised candidate — WSL instructions

**Use the exact-baseline builder, not the static zero-context preview.** The bundled static preview was assembled from source fragments only and is NOT verified as an applicable production patch. No filesystem writes to the repository occur until `git apply`.

```bash
cd /path/containing/the/unzipped/P03_package
REPO="/absolute/path/to/GPRobotControl_Simulation"
# Verify, do not switch or reset a dirty checkout:
git -C "$REPO" rev-parse HEAD
git -C "$REPO" branch --show-current
git -C "$REPO" status --short
# Builder enforces SHA=620da1bbdf7b33304c2040bfb518292ff256dc43,
# branch sara/can-replacement, and no overlapping dirty target files.
python3 p03_build_patch.py "$REPO" /tmp/P03_runtime_safety_liveness_v2.patch
cd "$REPO"
git apply --check /tmp/P03_runtime_safety_liveness_v2.patch
git apply /tmp/P03_runtime_safety_liveness_v2.patch
python3 Firmware/Tests/run_p03_runtime_evidence_tests.py
python3 Firmware/Tests/run_p03_cm4_service_tests.py
python3 Firmware/Tests/run_p03_supervisor_mutations.py
python3 Firmware/Tests/run_state_machine_alignment_tests.py
python3 Firmware/Tests/run_c2b_canopen_master_tests.py
python3 Firmware/Tests/run_a02_1_canopen_adapter_abi.py
python3 Firmware/Tests/run_drive_restart_gate_tests.py
python3 Firmware/Tests/run_supervision_policy_tests.py
python3 Firmware/Tests/check_c2a_wiring.py
python3 Firmware/Tests/check_c2b_wiring.py
bash Firmware/Tests/check_m4_application_ipc.sh
bash Intercore/Tests/run_ipc_freertos_runtime.sh
cmake -S . -B build/p03
cmake --build build/p03 -j4
ctest --test-dir build/p03 --output-on-failure
for core in CM7 CM4; do
    for cfg in Debug Release; do
        python3 Firmware/Tests/build_stm32.py --core "$core" --config "$cfg"
    done
done
python3 Firmware/Tests/check_firmware_integration.py --build-root build/stm32/Debug
python3 Firmware/Tests/check_firmware_integration.py --build-root build/stm32/Release
git diff --check
git diff --stat
git diff > /tmp/P03_actual_local_diff.patch
```

On ANY failed check, retain the failing command/log for Engineering Director review. The patch is not accepted until all applicable production tests and ARM builds pass. No commands above commit/push/merge/reset/delete branches. Never use the newly added software gate as proof of physical safety, STO, or a qualified reset detector.
